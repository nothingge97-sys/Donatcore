# DonateCore (Nukkit-MOT)

## Сборка
1. Установи JDK (та же версия, что у сервера) и Maven, либо открой папку в IntelliJ IDEA.
2. В `pom.xml` проверь зависимость Nukkit-MOT и версию Java по README проекта Nukkit-MOT.
3. `mvn package` -> `target/DonateCore-1.0.0.jar` -> в папку `plugins` сервера.
4. После первого запуска впиши свой ник в `plugins/DonateCore/config.yml` -> `owners`.

## Команды
| Команда | Что делает |
|---|---|
| /register, /login | авторизация |
| /pref | префиксы привилегий (своя и ниже; с Анти-Грифера и выше доступны нижние) |
| /cosmetic | косметические префиксы: надеть, купить за койны |
| /donshop | ДонШоп |
| /coins, /coins give/take/set ник N | баланс и управление (donate.admin) |
| /money, /money give/take/set ник N | игровые монеты (отдельно от койнов) |
| /case, /case give ник кейс N | кейсы (шансы в cases.yml), выдача ключей |
| /setrank ник id/none | выдать привилегию (id смотри в ranks.yml) |
| /limits | лимиты привилегии |
| /fly /heal /feed /ext /getpos | первые готовые команды из списка |

Всё настраивается в `ranks.yml`, `cosmetics.yml`, `shop.yml`.
Другие плагины (дома, регионы) могут брать лимиты через `DonatePlugin.getLimit(player, "homes", 0)`.

## Остальные команды
Наказания (ban/mute/kick и списки) с лимитами минут и задержками по привилегии, иммунитет Разраба;
варпы (/warp, /setwarp, /delwarp, /warpinfo); киты (kits.yml); /set pos1|pos2|блок + /undo;
подарки (/givefly, /givevip ... (один раз за всё время); настройки в config.yml -> gifts);
/god /back /top /cook /repair /repairall /milk /speed /size /vanish /nightvision /skin /delskin /statistics
/whois /near /invsee /player /burn /shock /scream /fakeop /rptp /tpme /tppos /spawn и др.
Встроенные /gamemode /tp /time /weather /enchant /clear остаются стандартными, права на них выдаёт привилегия (config.yml -> native_permissions).
Особые: /stick /tpbow /sleep /craft (экспериментально) /enderchest /enderchestsee /flyspeed (зависят от ядра) /ac (базовый) /console (список в config.yml).

## Дома, приваты, магазины
/sethome /home /delhome /homes /tpa /tpaccept /tpdeny /setspawn /spawn;
/rg pos1|pos2|claim|remove|info|list|addmember|delmember (алиас /region); /shop, /shop sell <цена>, /shop my.
Лимиты (дома, задержка телепорта, регионы, размер региона, лоты) берутся из привилегии, для игроков без неё - config.yml -> defaults.

## Антирелог
PvP на арене (создаётся /arena pos1, /arena pos2, /arena set <имя>) -> оба в бою 15 сек (config.yml -> combat). Выход в бою: вещи выпадают, игрок получает смерть в статистике. В бою отключён полёт и заблокированы команды из block_commands.

## Табло
Скорборд справа настраивается в config.yml -> scoreboard (строки, заголовок, ссылки). /sb - скрыть или показать. Клан пока всегда "нет" (кланов в плагине нет).

## Кланы и владельцы
/clan create|invite|accept|deny|leave|kick|transfer|disband|info|top|chat, /cc <сообщение>. Тег клана в чате и на табло ({clan}). Настройки: config.yml -> clans.
Владельцы: config.yml -> owners, порядок = приоритет (Awastyqq - Владелец, X1verus - Создатель).

## Кейс-блоки
Смотри на сундук: /case setblock <prefix|money|donate> - над ним крутятся призы (раз в 5 сек), ПКМ открывает меню кейсов. /case delblock, /case blocks. Ломать такие блоки могут только админы.
