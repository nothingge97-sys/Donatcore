package me.donate;

import cn.nukkit.utils.Config;

import java.util.*;

/** Привилегии и команда администрации из ranks.yml. Наследование считается здесь. */
public class Ranks {

    public static class Rank {
        public String id, name, prefix, inherits = "";
        public int price, order;
        public List<String> commands = new ArrayList<>();
        public Map<String, Integer> limits = new LinkedHashMap<>();
        public boolean prefixInherit, immunity, staff, op, permanent;
    }

    public final LinkedHashMap<String, Rank> donate = new LinkedHashMap<>();
    public final LinkedHashMap<String, Rank> staff = new LinkedHashMap<>();

    public Ranks(Config cfg) {
        int n = 0;
        for (Map.Entry<String, Object> e : U.m(cfg.get("ranks")).entrySet()) {
            Map<String, Object> m = U.m(e.getValue());
            Rank r = new Rank();
            r.id = e.getKey();
            r.name = U.s(m.get("name"), r.id);
            r.prefix = U.s(m.get("prefix"), "[" + r.name + "]");
            r.price = U.i(m.get("price"), 0);
            r.order = n++;
            for (Object c : U.l(m.get("commands"))) r.commands.add(String.valueOf(c));
            for (Map.Entry<String, Object> l : U.m(m.get("limits")).entrySet()) r.limits.put(l.getKey(), U.i(l.getValue(), 0));
            r.prefixInherit = U.b(m.get("prefix_inherit"), false);
            r.immunity = U.b(m.get("immunity"), false);
            donate.put(r.id, r);
        }
        for (Map.Entry<String, Object> e : U.m(cfg.get("staff")).entrySet()) {
            Map<String, Object> m = U.m(e.getValue());
            Rank r = new Rank();
            r.id = e.getKey();
            r.name = U.s(m.get("name"), r.id);
            r.prefix = U.s(m.get("prefix"), "[" + r.name + "]");
            r.inherits = U.s(m.get("inherits"), "");
            r.op = U.b(m.get("op"), false);
            r.permanent = U.b(m.get("permanent_punish"), false);
            r.staff = true;
            r.order = 1000 + n++;
            staff.put(r.id, r);
        }
    }

    public Rank byId(String id) {
        if (id == null || id.isEmpty()) return null;
        Rank r = donate.get(id);
        return r != null ? r : staff.get(id);
    }

    /** Донат-привилегии от первой до данной включительно (для staff - до inherits). */
    public List<Rank> chain(Rank r) {
        List<Rank> out = new ArrayList<>();
        if (r == null) return out;
        Rank top = r.staff ? donate.get(r.inherits) : r;
        if (top == null) return out;
        for (Rank x : donate.values()) {
            out.add(x);
            if (x == top) break;
        }
        return out;
    }

    public Set<String> commands(Rank r) {
        Set<String> s = new LinkedHashSet<>();
        for (Rank x : chain(r)) s.addAll(x.commands);
        return s;
    }

    public Map<String, Integer> limits(Rank r) {
        Map<String, Integer> out = new LinkedHashMap<>();
        for (Rank x : chain(r)) out.putAll(x.limits);
        return out;
    }

    public boolean immunity(Rank r) {
        for (Rank x : chain(r)) if (x.immunity) return true;
        return false;
    }

    /** Какие префиксы привилегий игрок может выбрать в /pref. */
    public List<Rank> selectablePrefixes(Rank r, boolean owner) {
        List<Rank> out = new ArrayList<>();
        if (owner) {
            out.addAll(donate.values());
            out.addAll(staff.values());
            return out;
        }
        if (r == null) return out;
        List<Rank> ch = chain(r);
        if (r.staff) {
            out.addAll(ch);
            out.add(r);
        } else if (r.prefixInherit) {
            out.addAll(ch);
        } else {
            out.add(r);
        }
        return out;
    }
}
