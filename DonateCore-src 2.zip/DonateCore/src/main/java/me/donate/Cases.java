package me.donate;

import cn.nukkit.Player;
import cn.nukkit.block.Block;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.block.BlockBreakEvent;
import cn.nukkit.event.player.PlayerInteractEvent;
import cn.nukkit.event.player.PlayerQuitEvent;
import cn.nukkit.level.Level;
import cn.nukkit.level.particle.FloatingTextParticle;
import cn.nukkit.math.Vector3;
import cn.nukkit.utils.Config;

import java.io.File;
import java.security.SecureRandom;
import java.util.*;

/** Кейсы: префикс, монеты, донат (привилегии). Данные и шансы - в cases.yml. */
public class Cases implements Listener {

    private static class Prize {
        String type, id;
        long amount;
        double chance;
    }

    private static class Def {
        String id, name, type;
        int priceCoins, rub;
        List<Prize> prizes = new ArrayList<>();
        double total;
    }

    private final DonatePlugin pl;
    private final LinkedHashMap<String, Def> defs = new LinkedHashMap<>();
    private final SecureRandom rnd = new SecureRandom();
    private int dupPercent, rankPerRub;
    private double bcast;
    private String donateInfo, footer;
    private int rotateSec;

    // ---- кейс-блоки в мире (сундуки): голограмма с призами и открытие по клику ----
    private static class CB {
        String level, caseId;
        int x, y, z;
        String key() { return level + ":" + x + ":" + y + ":" + z; }
    }
    private final Config blocksCfg;
    private final List<CB> blocks = new ArrayList<>();
    private final Map<String, FloatingTextParticle> holo = new HashMap<>();
    private final Map<String, String> holoText = new HashMap<>();
    private final Map<String, Set<UUID>> holoSeen = new HashMap<>();
    private final Map<UUID, Long> clickTime = new HashMap<>();
    private long secs;

    public Cases(DonatePlugin pl, Config cfg) {
        this.pl = pl;
        Map<String, Object> st = U.m(cfg.get("settings"));
        dupPercent = U.i(st.get("duplicate_refund_percent"), 50);
        rankPerRub = U.i(st.get("rank_duplicate_coins_per_rub"), 2);
        bcast = U.i(st.get("broadcast_below_percent"), 3);
        donateInfo = U.s(st.get("donate_info"), "Кейс недоступен для покупки за койны.");
        footer = U.s(st.get("hologram_footer"), "");
        rotateSec = Math.max(1, U.i(st.get("hologram_rotate_seconds"), 5));
        blocksCfg = new Config(new File(pl.getDataFolder(), "caseblocks.yml"), Config.YAML);
        for (Object o : U.l(blocksCfg.get("blocks"))) {
            Map<String, Object> m = U.m(o);
            CB b = new CB();
            b.level = U.s(m.get("level"), ""); b.caseId = U.s(m.get("case"), "");
            b.x = U.i(m.get("x"), 0); b.y = U.i(m.get("y"), 0); b.z = U.i(m.get("z"), 0);
            blocks.add(b);
        }
        pl.getServer().getScheduler().scheduleRepeatingTask(pl, this::holoTick, 20);
        for (Map.Entry<String, Object> e : U.m(cfg.get("cases")).entrySet()) {
            Map<String, Object> m = U.m(e.getValue());
            Def d = new Def();
            d.id = e.getKey();
            d.name = U.s(m.get("name"), d.id);
            d.type = U.s(m.get("type"), "money");
            d.priceCoins = U.i(m.get("price_coins"), 0);
            d.rub = U.i(m.get("rub"), 0);
            for (Object o : U.l(m.get("prizes"))) {
                Map<String, Object> pm = U.m(o);
                Prize p = new Prize();
                p.type = d.type;
                p.id = U.s(pm.get("id"), "");
                p.amount = pm.get("amount") instanceof Number ? ((Number) pm.get("amount")).longValue() : 0;
                p.chance = pm.get("chance") instanceof Number ? ((Number) pm.get("chance")).doubleValue() : 0;
                if (p.chance <= 0) continue;
                d.prizes.add(p);
                d.total += p.chance;
            }
            defs.put(d.id, d);
        }
    }

    public boolean exists(String id) {
        return defs.containsKey(id);
    }

    public Set<String> ids() {
        return defs.keySet();
    }

    // ---------------------------------------------------------------- меню

    public void menu(Player p) {
        List<Def> l = new ArrayList<>(defs.values());
        Store.PD d = pl.store.get(p.getName());
        List<String> b = new ArrayList<>();
        for (Def c : l) b.add(c.name + "\n§7У вас: §f" + d.keys.getOrDefault(c.id, 0) + " кл.");
        pl.forms.simple(p, "§l§eКейсы", "Выбери кейс для открытия:", b,
                idx -> { if (idx >= 0 && idx < l.size()) detail(p, l.get(idx)); });
    }

    private void detail(Player p, Def c) {
        int myKeys = pl.store.get(p.getName()).keys.getOrDefault(c.id, 0);
        StringBuilder sb = new StringBuilder(c.name).append("\n\n§fЦена: §e")
                .append(c.priceCoins > 0 ? c.priceCoins + " койнов" : c.rub + " ₽ (по ключу)")
                .append("\n§fВаших ключей: §e").append(myKeys).append("\n\n§fШансы:");
        for (Prize pr : c.prizes) sb.append("\n§7").append(label(pr)).append("§7 - ").append(trim(pr.chance)).append("%");
        pl.forms.simple(p, c.name, sb.toString(), Arrays.asList("§aОткрыть", "§7Назад"), idx -> {
            if (idx == 0) open(p, c);
            else menu(p);
        });
    }

    private String trim(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    private String label(Prize pr) {
        switch (pr.type) {
            case "cosmetic": {
                Cosmetics.Cos c = pl.cosmetics.get(pr.id);
                return c == null ? pr.id : c.prefix;
            }
            case "rank": {
                Ranks.Rank r = pl.ranks.byId(pr.id);
                return r == null ? pr.id : r.prefix;
            }
            default:
                return "§6" + String.format("%,d", pr.amount).replace(',', ' ') + " монет";
        }
    }

    // ---------------------------------------------------------------- открытие

    public void open(Player p, Def c) {
        if (!pl.isAuthed(p)) return;
        Store.PD d = pl.store.get(p.getName());
        int keys = d.keys.getOrDefault(c.id, 0);
        if (c.prizes.isEmpty() || c.total <= 0) { p.sendMessage("§cКейс пуст (ошибка конфигурации)."); return; }
        if (keys > 0) {
            if (keys == 1) d.keys.remove(c.id); else d.keys.put(c.id, keys - 1);
        } else if (c.priceCoins > 0) {
            if (d.coins < c.priceCoins) {
                p.sendMessage("§cНужно " + c.priceCoins + " койнов, у вас " + d.coins + ".");
                return;
            }
            d.coins -= c.priceCoins;
        } else {
            p.sendMessage("§e" + donateInfo);
            return;
        }
        Prize pr = roll(c);
        String result = award(p, d, pr);
        pl.store.save();
        animate(p, c, pr, result);
        pl.getLogger().info(p.getName() + " открыл " + c.id + ": " + pr.type + " " + (pr.id.isEmpty() ? pr.amount : pr.id));
    }

    private Prize roll(Def c) {
        double x = rnd.nextDouble() * c.total;
        double acc = 0;
        for (Prize p : c.prizes) {
            acc += p.chance;
            if (x < acc) return p;
        }
        return c.prizes.get(c.prizes.size() - 1);
    }

    /** Выдаёт приз сразу (анимация только для красоты). Возвращает текст результата. */
    private String award(Player p, Store.PD d, Prize pr) {
        switch (pr.type) {
            case "cosmetic": {
                Cosmetics.Cos c = pl.cosmetics.get(pr.id);
                if (c == null) return "§cОшибка приза";
                if (d.cosmetics.contains(c.id)) {
                    long back = (long) c.price * dupPercent / 100;
                    d.coins += back;
                    return c.prefix + " §7(уже есть, возврат §e" + back + "§7 койнов)";
                }
                d.cosmetics.add(c.id);
                return c.prefix + " §a- наденьте в /cosmetic";
            }
            case "rank": {
                Ranks.Rank r = pl.ranks.byId(pr.id);
                if (r == null) return "§cОшибка приза";
                Ranks.Rank cur = pl.ranks.byId(d.rank);
                if (cur == null || cur.order < r.order) {
                    d.rank = r.id;
                    if (pl.isAuthed(p)) pl.applyPerms(p);
                    return r.prefix + " §aпривилегия!";
                }
                long back = (long) r.price * rankPerRub;
                d.coins += back;
                return r.prefix + " §7(у вас уже такая или выше, компенсация §e" + back + "§7 койнов)";
            }
            default:
                d.money += pr.amount;
                return "§6" + pr.amount + " монет";
        }
    }

    private void animate(Player p, Def c, Prize pr, String result) {
        for (int i = 1; i <= 8; i++) {
            Prize fake = c.prizes.get(rnd.nextInt(c.prizes.size()));
            pl.getServer().getScheduler().scheduleDelayedTask(pl, () -> {
                if (p.isOnline()) p.sendTitle(label(fake), c.name, 0, 6, 0);
            }, i * 4);
        }
        pl.getServer().getScheduler().scheduleDelayedTask(pl, () -> {
            if (p.isOnline()) {
                p.sendTitle(label(pr), "§aВаш приз!", 0, 40, 10);
                p.sendMessage("§eИз кейса " + c.name + "§e выпало: " + result);
            }
            if (pr.chance / c.total * 100 <= bcast)
                pl.getServer().broadcastMessage("§6§l" + p.getName() + " §eвыбил §f" + label(pr) + " §eиз " + c.name + "§e!");
        }, 40);
    }

    // ---------------------------------------------------------------- админ

    public String giveKeys(String nick, String caseId, int n) {
        if (!defs.containsKey(caseId)) return "§cТакого кейса нет. Доступно: " + String.join(", ", defs.keySet());
        if (n <= 0 || n > 1000) return "§cКоличество от 1 до 1000.";
        Store.PD d = pl.store.get(nick);
        d.keys.merge(caseId, n, Integer::sum);
        pl.store.save();
        Player on = pl.getServer().getPlayerExact(nick);
        if (on != null) on.sendMessage("§aВам выдано ключей: " + n + " (" + defs.get(caseId).name + "§a). Открыть: /case");
        return "§aВыдано ключей " + caseId + " игроку " + nick + ": " + n;
    }

    public Def get(String id) {
        return defs.get(id);
    }

    // ---------------------------------------------------------------- кейс-блоки

    private void saveBlocks() {
        List<Object> out = new ArrayList<>();
        for (CB b : blocks) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("level", b.level); m.put("case", b.caseId);
            m.put("x", b.x); m.put("y", b.y); m.put("z", b.z);
            out.add(m);
        }
        blocksCfg.set("blocks", out);
        blocksCfg.save();
    }

    private CB blockAt(Block bl) {
        if (bl == null || bl.getLevel() == null) return null;
        String lv = bl.getLevel().getName();
        for (CB b : blocks) if (b.level.equals(lv) && b.x == bl.getFloorX() && b.y == bl.getFloorY() && b.z == bl.getFloorZ()) return b;
        return null;
    }

    /** /case setblock <кейс>, /case delblock, /case blocks - смотри на сундук и вводи команду. */
    public boolean blockCommand(Player p, String sub, String[] a) {
        if (!p.hasPermission("donate.admin")) { p.sendMessage("§cНет прав."); return true; }
        if (sub.equals("blocks")) {
            p.sendMessage(blocks.isEmpty() ? "§7Кейс-блоков нет." : "§eКейс-блоки: §f" + blocks.size());
            for (CB b : blocks) p.sendMessage("§7" + b.caseId + " §f" + b.level + " " + b.x + ", " + b.y + ", " + b.z);
            return true;
        }
        Block t = p.getTargetBlock(6);
        if (t == null || t.getId() == 0) { p.sendMessage("§cПодойдите ближе и смотрите на блок (сундук) не дальше 6 блоков."); return true; }
        CB ex = blockAt(t);
        if (sub.equals("delblock")) {
            if (ex == null) { p.sendMessage("§cЭтот блок не привязан к кейсу."); return true; }
            removeBlock(ex);
            p.sendMessage("§aКейс-блок удалён.");
            return true;
        }
        if (a.length < 2 || !defs.containsKey(a[1].toLowerCase(Locale.ROOT))) {
            p.sendMessage("§c/case setblock <" + String.join("|", defs.keySet()) + "> (смотрите на сундук)");
            return true;
        }
        if (ex != null) removeBlock(ex);
        CB b = new CB();
        b.level = t.getLevel().getName(); b.caseId = a[1].toLowerCase(Locale.ROOT);
        b.x = t.getFloorX(); b.y = t.getFloorY(); b.z = t.getFloorZ();
        blocks.add(b);
        saveBlocks();
        p.sendMessage("§aБлок стал кейсом " + defs.get(b.caseId).name + "§a: над ним крутятся призы, клик открывает меню.");
        return true;
    }

    private void removeBlock(CB b) {
        String key = b.key();
        FloatingTextParticle fp = holo.remove(key);
        Set<UUID> seen = holoSeen.remove(key);
        holoText.remove(key);
        if (fp != null && seen != null) {
            fp.setInvisible(true);
            Level lv = pl.getServer().getLevelByName(b.level);
            if (lv != null)
                for (UUID id : seen) pl.getServer().getPlayer(id).ifPresent(pp -> lv.addParticle(fp, pp));
        }
        blocks.remove(b);
        saveBlocks();
    }

    /** Раз в секунду: меняем приз над сундуком каждые hologram_rotate_seconds и показываем игрокам рядом. */
    private void holoTick() {
        secs++;
        for (int bi = 0; bi < blocks.size(); bi++) {
            CB b = blocks.get(bi);
            Def c = defs.get(b.caseId);
            Level lv = pl.getServer().getLevelByName(b.level);
            if (c == null || c.prizes.isEmpty() || c.total <= 0 || lv == null) continue;
            String key = b.key();
            Prize pr = c.prizes.get((int) ((secs / rotateSec + bi) % c.prizes.size()));
            String text = "§7Выпадает: " + label(pr) + " §7(" + trim(Math.round(pr.chance / c.total * 1000) / 10.0) + "%)\n§eНажмите, чтобы открыть"
                    + (footer.isEmpty() ? "" : "\n" + footer);
            Vector3 pos = new Vector3(b.x + 0.5, b.y + 1.4, b.z + 0.5);
            FloatingTextParticle fp = holo.computeIfAbsent(key, k -> new FloatingTextParticle(pos, c.name, text));
            fp.setTitle(c.name);
            fp.setText(text);
            boolean changed = !text.equals(holoText.get(key));
            holoText.put(key, text);
            Set<UUID> seen = holoSeen.computeIfAbsent(key, k -> new HashSet<>());
            for (Player p : pl.getServer().getOnlinePlayers().values()) {
                boolean near = p.getLevel() == lv && p.distance(pos) <= 40;
                if (!near) { seen.remove(p.getUniqueId()); continue; }
                if (changed || !seen.contains(p.getUniqueId())) {
                    lv.addParticle(fp, p);
                    seen.add(p.getUniqueId());
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) return;
        CB b = blockAt(e.getBlock());
        if (b == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!pl.isAuthed(p)) return;
        long now = System.currentTimeMillis();
        Long last = clickTime.get(p.getUniqueId());
        if (last != null && now - last < 600) return; // Bedrock шлёт клик дважды
        clickTime.put(p.getUniqueId(), now);
        menu(p);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        CB b = blockAt(e.getBlock());
        if (b == null) return;
        if (!e.getPlayer().hasPermission("donate.admin")) {
            e.setCancelled(true);
            return;
        }
        removeBlock(b);
        e.getPlayer().sendMessage("§eКейс-блок удалён вместе с блоком.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        clickTime.remove(id);
        for (Set<UUID> s : holoSeen.values()) s.remove(id);
    }
}
