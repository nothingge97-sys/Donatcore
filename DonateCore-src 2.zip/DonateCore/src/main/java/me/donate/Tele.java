package me.donate;

import cn.nukkit.Player;
import cn.nukkit.command.CommandSender;
import cn.nukkit.level.Level;
import cn.nukkit.level.Location;
import cn.nukkit.math.Vector3;
import cn.nukkit.utils.Config;

import java.io.File;
import java.util.*;

/** Дома, телепорты между игроками (/tpa), задержка телепорта по привилегии, /setspawn. */
public class Tele {

    private final DonatePlugin pl;
    private final Config cfg;
    private final Map<String, Map<String, Map<String, Object>>> homes = new LinkedHashMap<>();
    private final Map<UUID, Integer> pending = new HashMap<>();
    private final Map<UUID, UUID> tpaFrom = new HashMap<>();   // получатель -> отправитель
    private final Map<UUID, Long> tpaTime = new HashMap<>();
    private int counter;

    public Tele(DonatePlugin pl) {
        this.pl = pl;
        cfg = new Config(new File(pl.getDataFolder(), "homes.yml"), Config.YAML);
        for (Map.Entry<String, Object> e : cfg.getAll().entrySet()) {
            Map<String, Map<String, Object>> hm = new LinkedHashMap<>();
            for (Map.Entry<String, Object> h : U.m(e.getValue()).entrySet()) hm.put(h.getKey(), U.m(h.getValue()));
            homes.put(e.getKey(), hm);
        }
    }

    private void save() {
        cfg.setAll(new LinkedHashMap<String, Object>(homes));
        cfg.save();
    }

    // ------------------------------------------------------------ задержка телепорта

    public int delay(Player p) {
        // Задержка выключена глобально (config.yml -> teleport_delay: false). Включить: true.
        if (!U.b(pl.config.get("teleport_delay"), false)) return 0;
        if (pl.isOwner(p)) return 0;
        Ranks.Rank r = pl.rankOf(p);
        Integer v = r == null ? null : pl.ranks.limits(r).get("tp_delay");
        return v != null ? v : U.i(U.m(pl.config.get("defaults")).get("tp_delay"), 3);
    }

    /** Телепорт с обратным отсчётом (отменяется, если игрок сдвинулся). */
    public void go(Player p, Location dest, String what) {
        int d = delay(p);
        if (d <= 0) {
            p.teleport(dest);
            p.sendMessage("§aТелепорт: " + what);
            return;
        }
        UUID id = p.getUniqueId();
        int token = ++counter;
        pending.put(id, token);
        p.sendMessage("§eТелепорт через " + d + " сек. Не двигайтесь!");
        tick(p, dest, what, d, new Vector3(p.x, p.y, p.z), token);
    }

    private void tick(Player p, Location dest, String what, int left, Vector3 start, int token) {
        pl.getServer().getScheduler().scheduleDelayedTask(pl, () -> {
            UUID id = p.getUniqueId();
            Integer cur = pending.get(id);
            if (cur == null || cur != token || !p.isOnline()) return;
            if (p.distance(start) > 0.8) {
                pending.remove(id);
                p.sendMessage("§cТелепорт отменён: вы двигались.");
                return;
            }
            if (left - 1 <= 0) {
                pending.remove(id);
                p.teleport(dest);
                p.sendMessage("§aТелепорт: " + what);
            } else {
                tick(p, dest, what, left - 1, start, token);
            }
        }, 20);
    }

    public void onQuit(Player p) {
        pending.remove(p.getUniqueId());
        tpaFrom.remove(p.getUniqueId());
    }

    // ------------------------------------------------------------ команды

    public boolean handle(CommandSender s, String c, String[] a) {
        if (c.equals("setspawn")) return setspawn(s);
        if (!(s instanceof Player)) { s.sendMessage("Эту команду можно выполнить только в игре."); return true; }
        Player p = (Player) s;
        switch (c) {
            case "sethome": return sethome(p, a);
            case "home": return home(p, a);
            case "delhome": return delhome(p, a);
            case "homes": return homesList(p);
            case "tpa": return tpa(p, a);
            case "tpaccept": return tpaccept(p);
            case "tpdeny": return tpdeny(p);
            default: return false;
        }
    }

    private Map<String, Map<String, Object>> mine(Player p) {
        return homes.computeIfAbsent(p.getName().toLowerCase(Locale.ROOT).replace('.', '_'), k -> new LinkedHashMap<>());
    }

    private boolean sethome(Player p, String[] a) {
        String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "home";
        if (!name.matches("[\\p{L}0-9_\\-]{1,24}")) { p.sendMessage("§cИмя: буквы, цифры, _ и -, до 24 символов."); return true; }
        Map<String, Map<String, Object>> h = mine(p);
        if (!h.containsKey(name) && h.size() >= pl.lim(p, "homes")) {
            p.sendMessage("§cЛимит домов вашей привилегии: " + pl.lim(p, "homes") + ". Удалите старый: /delhome <имя>");
            return true;
        }
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("level", p.getLevel().getName());
        m.put("x", p.x); m.put("y", p.y); m.put("z", p.z); m.put("yaw", p.yaw); m.put("pitch", p.pitch);
        h.put(name, m);
        save();
        p.sendMessage("§aДом " + name + " установлен.");
        return true;
    }

    private double d(Object o) {
        return o instanceof Number ? ((Number) o).doubleValue() : 0;
    }

    private boolean home(Player p, String[] a) {
        Map<String, Map<String, Object>> h = mine(p);
        if (h.isEmpty()) { p.sendMessage("§cУ вас нет домов. /sethome [имя]"); return true; }
        String name = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : (h.containsKey("home") ? "home" : (h.size() == 1 ? h.keySet().iterator().next() : null));
        if (name == null) { p.sendMessage("§eВаши дома: §f" + String.join(", ", h.keySet()) + "\n§7/home <имя>"); return true; }
        Map<String, Object> m = h.get(name);
        if (m == null) { p.sendMessage("§cТакого дома нет. Ваши дома: " + String.join(", ", h.keySet())); return true; }
        Level lv = pl.getServer().getLevelByName(U.s(m.get("level"), ""));
        if (lv == null) { p.sendMessage("§cМир дома не загружен."); return true; }
        go(p, new Location(d(m.get("x")), d(m.get("y")), d(m.get("z")), d(m.get("yaw")), d(m.get("pitch")), lv), "дом " + name);
        return true;
    }

    private boolean delhome(Player p, String[] a) {
        if (a.length < 1) { p.sendMessage("§c/delhome <имя>"); return true; }
        if (mine(p).remove(a[0].toLowerCase(Locale.ROOT)) == null) { p.sendMessage("§cТакого дома нет."); return true; }
        save();
        p.sendMessage("§aДом удалён.");
        return true;
    }

    private boolean homesList(Player p) {
        Map<String, Map<String, Object>> h = mine(p);
        p.sendMessage("§eДома (" + h.size() + "/" + (pl.isOwner(p) ? "∞" : String.valueOf(pl.lim(p, "homes"))) + "): §f"
                + (h.isEmpty() ? "нет" : String.join(", ", h.keySet())));
        return true;
    }

    // ------------------------------------------------------------ /tpa

    private boolean tpa(Player p, String[] a) {
        if (a.length < 1) { p.sendMessage("§c/tpa <игрок>"); return true; }
        Player t = pl.getServer().getPlayer(a[0]);
        if (t == null || t == p) { p.sendMessage("§cИгрок не найден."); return true; }
        tpaFrom.put(t.getUniqueId(), p.getUniqueId());
        tpaTime.put(t.getUniqueId(), System.currentTimeMillis());
        p.sendMessage("§aЗапрос отправлен игроку " + t.getName() + ".");
        t.sendMessage("§e" + p.getName() + " хочет телепортироваться к вам. §a/tpaccept §eили §c/tpdeny §7(60 сек)");
        return true;
    }

    private Player requester(Player p) {
        UUID from = tpaFrom.get(p.getUniqueId());
        Long t = tpaTime.get(p.getUniqueId());
        if (from == null || t == null || System.currentTimeMillis() - t > 60_000) {
            p.sendMessage("§cНет активных запросов.");
            return null;
        }
        tpaFrom.remove(p.getUniqueId());
        Optional<Player> r = pl.getServer().getPlayer(from);
        if (!r.isPresent()) { p.sendMessage("§cИгрок ушёл с сервера."); return null; }
        return r.get();
    }

    private boolean tpaccept(Player p) {
        Player r = requester(p);
        if (r == null) return true;
        p.sendMessage("§aЗапрос принят.");
        go(r, p.getLocation(), "к " + p.getName());
        return true;
    }

    private boolean tpdeny(Player p) {
        Player r = requester(p);
        if (r == null) return true;
        p.sendMessage("§cЗапрос отклонён.");
        r.sendMessage("§c" + p.getName() + " отклонил запрос.");
        return true;
    }

    // ------------------------------------------------------------ /setspawn

    private boolean setspawn(CommandSender s) {
        if (!(s instanceof Player)) { s.sendMessage("Только в игре."); return true; }
        Player p = (Player) s;
        if (!p.hasPermission("donate.admin")) { p.sendMessage("§cНет прав."); return true; }
        p.getLevel().setSpawnLocation(new Vector3(p.x, p.y, p.z));
        p.sendMessage("§aСпавн мира " + p.getLevel().getName() + " установлен.");
        return true;
    }
}
