package me.donate;

import cn.nukkit.Player;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerFormRespondedEvent;
import cn.nukkit.event.player.PlayerQuitEvent;
import cn.nukkit.form.element.ElementButton;
import cn.nukkit.form.response.FormResponse;
import cn.nukkit.form.response.FormResponseModal;
import cn.nukkit.form.response.FormResponseSimple;
import cn.nukkit.form.window.FormWindowModal;
import cn.nukkit.form.window.FormWindowSimple;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/** Простая обёртка над формами: показать меню и получить номер нажатой кнопки. */
public class Forms implements Listener {

    private final Map<UUID, Map<Integer, Consumer<FormResponse>>> handlers = new HashMap<>();

    public void simple(Player p, String title, String content, List<String> buttons, IntConsumer onClick) {
        FormWindowSimple w = new FormWindowSimple(title, content);
        for (String b : buttons) w.addButton(new ElementButton(b));
        int id = p.showFormWindow(w);
        handlers.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).put(id, r -> {
            if (r instanceof FormResponseSimple) onClick.accept(((FormResponseSimple) r).getClickedButtonId());
        });
    }

    public void confirm(Player p, String title, String content, Runnable onYes) {
        FormWindowModal w = new FormWindowModal(title, content, "§aКупить", "§cОтмена");
        int id = p.showFormWindow(w);
        handlers.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).put(id, r -> {
            if (r instanceof FormResponseModal && ((FormResponseModal) r).getClickedButtonId() == 0) onYes.run();
        });
    }

    @EventHandler
    public void onForm(PlayerFormRespondedEvent e) {
        Map<Integer, Consumer<FormResponse>> m = handlers.get(e.getPlayer().getUniqueId());
        if (m == null) return;
        Consumer<FormResponse> c = m.remove(e.getFormID());
        if (c == null || e.wasClosed() || e.getResponse() == null) return;
        c.accept(e.getResponse());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        handlers.remove(e.getPlayer().getUniqueId());
    }
}
