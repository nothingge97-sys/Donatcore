package me.donate;

import cn.nukkit.utils.Config;

import java.util.LinkedHashMap;
import java.util.Map;

/** Косметические префиксы из cosmetics.yml (/cosmetic). */
public class Cosmetics {

    public static class Cos {
        public String id, name, prefix, rarity;
        public int price;
    }

    public final LinkedHashMap<String, Cos> all = new LinkedHashMap<>();

    public Cosmetics(Config cfg) {
        for (Map.Entry<String, Object> e : U.m(cfg.get("cosmetics")).entrySet()) {
            Map<String, Object> m = U.m(e.getValue());
            Cos c = new Cos();
            c.id = e.getKey();
            c.name = U.s(m.get("name"), c.id);
            c.prefix = U.s(m.get("prefix"), "[" + c.name + "]");
            c.price = U.i(m.get("price"), 0);
            c.rarity = U.s(m.get("rarity"), "common");
            all.put(c.id, c);
        }
    }

    public Cos get(String id) {
        return all.get(id);
    }
}
