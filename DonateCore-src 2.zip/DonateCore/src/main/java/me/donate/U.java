package me.donate;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Мелкие помощники для разбора YAML. */
public final class U {
    private U() {}

    public static int i(Object o, int def) {
        if (o instanceof Number) return ((Number) o).intValue();
        try { return o == null ? def : Integer.parseInt(String.valueOf(o).trim()); } catch (Exception e) { return def; }
    }

    public static String s(Object o, String def) {
        return o == null ? def : String.valueOf(o);
    }

    public static boolean b(Object o, boolean def) {
        if (o instanceof Boolean) return (Boolean) o;
        return o == null ? def : Boolean.parseBoolean(String.valueOf(o));
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> m(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : new LinkedHashMap<>();
    }

    public static List<Object> l(Object o) {
        return o instanceof List ? new ArrayList<>((List<?>) o) : new ArrayList<>();
    }
}
