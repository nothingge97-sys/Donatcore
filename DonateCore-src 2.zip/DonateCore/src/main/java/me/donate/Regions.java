package me.donate;

import cn.nukkit.Player;
import cn.nukkit.block.Block;
import cn.nukkit.command.CommandSender;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.block.BlockBreakEvent;
import cn.nukkit.event.block.BlockPlaceEvent;
import cn.nukkit.event.entity.EntityExplodeEvent;
import cn.nukkit.event.player.PlayerInteractEvent;
import cn.nukkit.event.player.PlayerQuitEvent;
import cn.nukkit.utils.Config;

import java.io.File;
import java.util.*;

/**
 * Приваты (регионы): прямоугольник по X/Z на всю высоту.
 * Лимиты привилегии: количество регионов (regions) и размер = площадь в блоках (region_size).
 */
public class Regions implements Listener {

    private static class Rg {
        String name, owner, level;
        int x1, z1, x2, z2;
        List<String> members = new ArrayList<>();
    }

    private final DonatePlugin pl;
    private final Config cfg;
    private final Map<String, Rg> map = new LinkedHashMap<>();
    private final Map<UUID, int[]> sel = new HashMap<>();       // x1,z1,x2,z2, set1, set2
    private final Map<UUID, String> selLevel = new HashMap<>();

    public Regions(DonatePlugin pl) {
        this.pl = pl;
        cfg = new Config(new File(pl.getDataFolder(), "regions.yml"), Config.YAML);
        for (Map.Entry<String, Object> e : cfg.getAll().entrySet()) {
            Map<String, Object> m = U.m(e.getValue());
            Rg r = new Rg();
            r.name = e.getKey();
            r.owner = U.s(m.get("owner"), "");
            r.level = U.s(m.get("level"), "");
            r.x1 = U.i(m.get("x1"), 0); r.z1 = U.i(m.get("z1"), 0);
            r.x2 = U.i(m.get("x2"), 0); r.z2 = U.i(m.get("z2"), 0);
            for (Object o : U.l(m.get("members"))) r.members.add(String.valueOf(o));
            map.put(r.name, r);
        }
    }

    private void save() {
        LinkedHashMap<String, Object> out = new LinkedHashMap<>();
        for (Rg r : map.values()) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("owner", r.owner); m.put("level", r.level);
            m.put("x1", r.x1); m.put("z1", r.z1); m.put("x2", r.x2); m.put("z2", r.z2);
            m.put("members", new ArrayList<>(r.members));
            out.put(r.name, m);
        }
        cfg.setAll(out);
        cfg.save();
    }

    private Rg at(String level, int x, int z) {
        for (Rg r : map.values())
            if (r.level.equals(level) && x >= r.x1 && x <= r.x2 && z >= r.z1 && z <= r.z2) return r;
        return null;
    }

    private boolean allowed(Player p, Rg r) {
        return r == null || p.isOp() || p.hasPermission("donate.region.bypass")
                || r.owner.equalsIgnoreCase(p.getName()) || r.members.stream().anyMatch(m -> m.equalsIgnoreCase(p.getName()));
    }

    // ------------------------------------------------------------ команды /rg

    public boolean handle(CommandSender s, String[] a) {
        if (!(s instanceof Player)) { s.sendMessage("Эту команду можно выполнить только в игре."); return true; }
        Player p = (Player) s;
        String sub = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "help";
        switch (sub) {
            case "pos1": case "pos2": return pos(p, sub.equals("pos1"));
            case "claim": return claim(p, a);
            case "remove": return remove(p, a);
            case "info": return info(p, a);
            case "list": return list(p);
            case "addmember": return member(p, a, true);
            case "delmember": return member(p, a, false);
            default:
                p.sendMessage("§e/rg pos1, /rg pos2 §7- точки (где вы стоите)\n§e/rg claim <имя> §7- создать приват\n"
                        + "§e/rg remove <имя>, /rg info [имя], /rg list\n§e/rg addmember <имя> <игрок>, /rg delmember <имя> <игрок>");
                return true;
        }
    }

    private boolean pos(Player p, boolean first) {
        int[] st = sel.computeIfAbsent(p.getUniqueId(), k -> new int[6]);
        String lv = selLevel.get(p.getUniqueId());
        if (lv != null && !lv.equals(p.getLevel().getName())) { st[4] = 0; st[5] = 0; }
        selLevel.put(p.getUniqueId(), p.getLevel().getName());
        if (first) { st[0] = p.getFloorX(); st[1] = p.getFloorZ(); st[4] = 1; }
        else { st[2] = p.getFloorX(); st[3] = p.getFloorZ(); st[5] = 1; }
        p.sendMessage("§aТочка " + (first ? "1" : "2") + ": " + p.getFloorX() + ", " + p.getFloorZ());
        return true;
    }

    private boolean claim(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§c/rg claim <имя>"); return true; }
        String name = a[1].toLowerCase(Locale.ROOT);
        if (!name.matches("[\\p{L}0-9_\\-]{1,24}")) { p.sendMessage("§cИмя: буквы, цифры, _ и -, до 24 символов."); return true; }
        if (map.containsKey(name)) { p.sendMessage("§cРегион с таким именем уже есть."); return true; }
        int[] st = sel.get(p.getUniqueId());
        if (st == null || st[4] == 0 || st[5] == 0 || !p.getLevel().getName().equals(selLevel.get(p.getUniqueId()))) {
            p.sendMessage("§cСначала отметьте /rg pos1 и /rg pos2 в этом мире.");
            return true;
        }
        int x1 = Math.min(st[0], st[2]), x2 = Math.max(st[0], st[2]);
        int z1 = Math.min(st[1], st[3]), z2 = Math.max(st[1], st[3]);
        long area = (long) (x2 - x1 + 1) * (z2 - z1 + 1);
        long mineCount = map.values().stream().filter(r -> r.owner.equalsIgnoreCase(p.getName())).count();
        if (mineCount >= pl.lim(p, "regions")) { p.sendMessage("§cЛимит регионов вашей привилегии: " + pl.lim(p, "regions")); return true; }
        if (area > pl.lim(p, "region_size")) { p.sendMessage("§cОбласть " + area + " блоков, ваш лимит " + pl.lim(p, "region_size") + "."); return true; }
        for (Rg r : map.values()) {
            if (r.level.equals(p.getLevel().getName()) && x1 <= r.x2 && x2 >= r.x1 && z1 <= r.z2 && z2 >= r.z1) {
                p.sendMessage("§cОбласть пересекается с регионом " + r.name + " (" + r.owner + ").");
                return true;
            }
        }
        Rg r = new Rg();
        r.name = name; r.owner = p.getName(); r.level = p.getLevel().getName();
        r.x1 = x1; r.x2 = x2; r.z1 = z1; r.z2 = z2;
        map.put(name, r);
        save();
        p.sendMessage("§aРегион " + name + " создан (" + area + " блоков).");
        return true;
    }

    private boolean remove(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§c/rg remove <имя>"); return true; }
        Rg r = map.get(a[1].toLowerCase(Locale.ROOT));
        if (r == null) { p.sendMessage("§cТакого региона нет."); return true; }
        if (!r.owner.equalsIgnoreCase(p.getName()) && !p.hasPermission("donate.admin")) { p.sendMessage("§cЭто не ваш регион."); return true; }
        map.remove(r.name);
        save();
        p.sendMessage("§aРегион удалён.");
        return true;
    }

    private boolean info(Player p, String[] a) {
        Rg r = a.length > 1 ? map.get(a[1].toLowerCase(Locale.ROOT)) : at(p.getLevel().getName(), p.getFloorX(), p.getFloorZ());
        if (r == null) { p.sendMessage("§7Регион не найден."); return true; }
        p.sendMessage("§eРегион " + r.name + "\n§7Владелец: §f" + r.owner + "\n§7Участники: §f"
                + (r.members.isEmpty() ? "нет" : String.join(", ", r.members))
                + "\n§7Границы: §f" + r.x1 + "," + r.z1 + " - " + r.x2 + "," + r.z2 + " (" + r.level + ")");
        return true;
    }

    private boolean list(Player p) {
        List<String> n = new ArrayList<>();
        for (Rg r : map.values()) if (r.owner.equalsIgnoreCase(p.getName())) n.add(r.name);
        p.sendMessage("§eВаши регионы (" + n.size() + "/" + (pl.isOwner(p) ? "∞" : String.valueOf(pl.lim(p, "regions"))) + "): §f"
                + (n.isEmpty() ? "нет" : String.join(", ", n)));
        return true;
    }

    private boolean member(Player p, String[] a, boolean add) {
        if (a.length < 3) { p.sendMessage("§c/rg " + (add ? "addmember" : "delmember") + " <имя> <игрок>"); return true; }
        Rg r = map.get(a[1].toLowerCase(Locale.ROOT));
        if (r == null) { p.sendMessage("§cТакого региона нет."); return true; }
        if (!r.owner.equalsIgnoreCase(p.getName()) && !p.hasPermission("donate.admin")) { p.sendMessage("§cЭто не ваш регион."); return true; }
        if (add) { if (r.members.stream().noneMatch(m -> m.equalsIgnoreCase(a[2]))) r.members.add(a[2]); }
        else r.members.removeIf(m -> m.equalsIgnoreCase(a[2]));
        save();
        p.sendMessage("§aГотово.");
        return true;
    }

    // ------------------------------------------------------------ защита

    private boolean deny(Player p, Block b) {
        Rg r = at(b.getLevel().getName(), b.getFloorX(), b.getFloorZ());
        if (allowed(p, r)) return false;
        p.sendTip("§cПриватная территория игрока " + r.owner);
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (deny(e.getPlayer(), e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (deny(e.getPlayer(), e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK || e.getBlock() == null) return;
        if (deny(e.getPlayer(), e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        List<Block> keep = new ArrayList<>();
        for (Block b : e.getBlockList())
            if (at(b.getLevel().getName(), b.getFloorX(), b.getFloorZ()) == null) keep.add(b);
        e.setBlockList(keep);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        sel.remove(e.getPlayer().getUniqueId());
        selLevel.remove(e.getPlayer().getUniqueId());
        pl.tele.onQuit(e.getPlayer());
    }
}
