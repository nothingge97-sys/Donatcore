package me.donate;

import cn.nukkit.Player;
import cn.nukkit.command.CommandSender;
import cn.nukkit.item.Item;
import cn.nukkit.item.enchantment.Enchantment;
import cn.nukkit.nbt.tag.CompoundTag;
import cn.nukkit.nbt.tag.Tag;
import cn.nukkit.utils.Config;

import java.io.File;
import java.util.*;

/**
 * Магазины игроков: игрок выставляет предмет из руки за игровые монеты (/shop sell <цена>),
 * все видят каталог в /shop. Лимит выставленных лотов - shops из привилегии.
 */
public class PShop {

    private static class Listing {
        int id;
        String owner;
        long price;
        Map<String, Object> item;
    }

    private static final Set<String> SAFE_TAGS = new HashSet<>(Arrays.asList("display", "ench", "Damage", "RepairCost"));

    private final DonatePlugin pl;
    private final Config cfg;
    private final List<Listing> list = new ArrayList<>();
    private int next = 1;

    public PShop(DonatePlugin pl) {
        this.pl = pl;
        cfg = new Config(new File(pl.getDataFolder(), "shops.yml"), Config.YAML);
        for (Object o : U.l(cfg.get("listings"))) {
            Map<String, Object> m = U.m(o);
            Listing l = new Listing();
            l.id = U.i(m.get("id"), 0);
            l.owner = U.s(m.get("owner"), "");
            l.price = m.get("price") instanceof Number ? ((Number) m.get("price")).longValue() : 0;
            l.item = U.m(m.get("item"));
            list.add(l);
            next = Math.max(next, l.id + 1);
        }
    }

    private void save() {
        List<Object> out = new ArrayList<>();
        for (Listing l : list) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("id", l.id); m.put("owner", l.owner); m.put("price", l.price); m.put("item", l.item);
            out.add(m);
        }
        cfg.set("listings", out);
        cfg.save();
    }

    // ------------------------------------------------------------ предмет <-> данные

    private Map<String, Object> pack(Item it) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", it.getId());
        m.put("meta", it.getDamage());
        m.put("count", it.getCount());
        if (it.hasCustomName()) m.put("name", it.getCustomName());
        String[] lore = it.getLore();
        if (lore != null && lore.length > 0) m.put("lore", new ArrayList<>(Arrays.asList(lore)));
        List<Object> en = new ArrayList<>();
        for (Enchantment e : it.getEnchantments()) en.add(Arrays.asList(e.getId(), e.getLevel()));
        if (!en.isEmpty()) m.put("ench", en);
        return m;
    }

    private Item unpack(Map<String, Object> m) {
        Item it = Item.get(U.i(m.get("id"), 0), U.i(m.get("meta"), 0), U.i(m.get("count"), 1));
        if (m.containsKey("name")) it.setCustomName(U.s(m.get("name"), ""));
        List<Object> lore = U.l(m.get("lore"));
        if (!lore.isEmpty()) {
            String[] arr = new String[lore.size()];
            for (int i = 0; i < arr.length; i++) arr[i] = String.valueOf(lore.get(i));
            it.setLore(arr);
        }
        for (Object o : U.l(m.get("ench"))) {
            List<Object> pair = U.l(o);
            if (pair.size() != 2) continue;
            Enchantment e = Enchantment.getEnchantment(U.i(pair.get(0), 0));
            if (e != null) it.addEnchantment(e.setLevel(U.i(pair.get(1), 1), false));
        }
        return it;
    }

    private String title(Map<String, Object> m) {
        String n = m.containsKey("name") ? U.s(m.get("name"), "") : unpack(m).getName();
        return n + " §7x" + U.i(m.get("count"), 1);
    }

    /** Можно ли выставить предмет: без особых NBT (донат-предметы, содержимое и т.п.). */
    private boolean sellable(Item it) {
        if (it == null || it.getId() == 0) return false;
        if (!it.hasCompoundTag()) return true;
        CompoundTag tag = it.getNamedTag();
        for (Tag t : tag.getAllTags()) if (!SAFE_TAGS.contains(t.getName())) return false;
        return true;
    }

    // ------------------------------------------------------------ команда /shop

    public boolean handle(CommandSender s, String[] a) {
        if (!(s instanceof Player)) { s.sendMessage("Эту команду можно выполнить только в игре."); return true; }
        Player p = (Player) s;
        if (a.length >= 1 && a[0].equalsIgnoreCase("sell")) return sell(p, a);
        if (a.length >= 1 && a[0].equalsIgnoreCase("my")) { mine(p); return true; }
        catalog(p, 0);
        return true;
    }

    private boolean sell(Player p, String[] a) {
        if (a.length < 2) { p.sendMessage("§c/shop sell <цена в монетах> - выставить предмет из руки"); return true; }
        long price;
        try { price = Long.parseLong(a[1]); } catch (NumberFormatException e) { p.sendMessage("§cЦена должна быть числом."); return true; }
        if (price < 1 || price > 1_000_000_000L) { p.sendMessage("§cЦена от 1 до 1 000 000 000 монет."); return true; }
        Item hand = p.getInventory().getItemInHand();
        if (!sellable(hand)) { p.sendMessage("§cЭтот предмет нельзя продать (пусто в руке или особый предмет)."); return true; }
        long mine = list.stream().filter(l -> l.owner.equalsIgnoreCase(p.getName())).count();
        if (mine >= pl.lim(p, "shops")) { p.sendMessage("§cЛимит лотов вашей привилегии: " + pl.lim(p, "shops") + ". Снимите старый: /shop my"); return true; }
        Listing l = new Listing();
        l.id = next++;
        l.owner = p.getName();
        l.price = price;
        l.item = pack(hand);
        list.add(l);
        p.getInventory().setItemInHand(Item.get(0));
        save();
        p.sendMessage("§aВыставлено: " + title(l.item) + " §aза " + price + " монет.");
        return true;
    }

    private void catalog(Player p, int page) {
        int per = 8;
        int pages = Math.max(1, (list.size() + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));
        List<Listing> sub = list.subList(page * per, Math.min(list.size(), page * per + per));
        List<String> b = new ArrayList<>();
        for (Listing l : sub) b.add(title(l.item) + "\n§8" + l.price + " монет | " + l.owner);
        int prevIdx = page > 0 ? b.size() : -1;
        if (page > 0) b.add("§7« Назад");
        int nextIdx = page < pages - 1 ? b.size() : -1;
        if (page < pages - 1) b.add("§7Далее »");
        final int pg = page;
        pl.forms.simple(p, "§l§6Магазины игроков (" + (pg + 1) + "/" + pages + ")",
                "Ваши монеты: §e" + pl.store.get(p.getName()).money + (list.isEmpty() ? "\n§7Пока ничего не продаётся. Выставить: /shop sell <цена>" : ""), b, idx -> {
                    if (idx >= 0 && idx < sub.size()) {
                        Listing l = sub.get(idx);
                        pl.forms.confirm(p, "Покупка", title(l.item) + "\n\nЦена: §e" + l.price + " монет\n§7Продавец: " + l.owner, () -> buy(p, l.id));
                    } else if (idx == prevIdx) catalog(p, pg - 1);
                    else if (idx == nextIdx) catalog(p, pg + 1);
                });
    }

    private void buy(Player p, int id) {
        Listing l = null;
        for (Listing x : list) if (x.id == id) l = x;
        if (l == null) { p.sendMessage("§cЛот уже продан или снят."); return; }
        if (l.owner.equalsIgnoreCase(p.getName())) { p.sendMessage("§cЭто ваш лот. Снять: /shop my"); return; }
        Store.PD me = pl.store.get(p.getName());
        if (me.money < l.price) { p.sendMessage("§cНедостаточно монет. Нужно " + l.price + ", у вас " + me.money + "."); return; }
        list.remove(l);
        me.money -= l.price;
        pl.store.get(l.owner).money += l.price;
        pl.store.save();
        save();
        for (Item left : p.getInventory().addItem(unpack(l.item))) p.getLevel().dropItem(p, left);
        p.sendMessage("§aВы купили " + title(l.item) + " §aза " + l.price + " монет.");
        Player seller = pl.getServer().getPlayerExact(l.owner);
        if (seller != null) seller.sendMessage("§aВаш лот " + title(l.item) + " §aкуплен игроком " + p.getName() + " за " + l.price + " монет.");
        pl.getLogger().info(p.getName() + " купил лот " + l.id + " у " + l.owner + " за " + l.price);
    }

    private void mine(Player p) {
        List<Listing> my = new ArrayList<>();
        for (Listing l : list) if (l.owner.equalsIgnoreCase(p.getName())) my.add(l);
        if (my.isEmpty()) { p.sendMessage("§7У вас нет лотов. Выставить: /shop sell <цена>"); return; }
        List<String> b = new ArrayList<>();
        for (Listing l : my) b.add(title(l.item) + "\n§8" + l.price + " монет");
        pl.forms.simple(p, "Мои лоты", "Нажмите, чтобы снять с продажи:", b, idx -> {
            if (idx < 0 || idx >= my.size()) return;
            Listing l = my.get(idx);
            pl.forms.simple(p, title(l.item), "Цена: " + l.price + " монет", Arrays.asList("§cСнять с продажи", "§7Назад"), i2 -> {
                if (i2 != 0 || !list.remove(l)) return;
                save();
                for (Item left : p.getInventory().addItem(unpack(l.item))) p.getLevel().dropItem(p, left);
                p.sendMessage("§aЛот снят, предмет возвращён.");
            });
        });
    }
}
