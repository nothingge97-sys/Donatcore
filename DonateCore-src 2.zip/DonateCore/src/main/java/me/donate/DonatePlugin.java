package me.donate;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.EventPriority;
import cn.nukkit.event.Listener;
import cn.nukkit.event.block.BlockBreakEvent;
import cn.nukkit.event.block.BlockPlaceEvent;
import cn.nukkit.event.entity.EntityDamageEvent;
import cn.nukkit.event.player.*;
import cn.nukkit.permission.PermissionAttachment;
import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.Config;
import cn.nukkit.utils.TextFormat;

import java.io.File;
import java.util.*;

public class DonatePlugin extends PluginBase implements Listener {

    public Store store;
    public Ranks ranks;
    public Cosmetics cosmetics;
    public Shop shop;
    public Forms forms;
    public Cmds cmds;
    public Cases cases;
    public Extra extra;
    public Tele tele;
    public Combat combat;
    public Board board;
    public Clans clans;
    public Regions regions;
    public PShop pshop;
    public Config config;

    private final Set<UUID> authed = new HashSet<>();
    private final Map<UUID, Integer> attempts = new HashMap<>();
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private Set<String> owners = new HashSet<>();
    private List<String> ownerOrder = new ArrayList<>(); // порядок в config.yml = приоритет (первый - главный)
    private Map<String, String> ownerDisplay = new HashMap<>(); // ник -> id ранга, который ПОКАЗЫВАЕТСЯ (не влияет на реальный приоритет)
    private boolean ownersNeedXbox;

    @Override
    public void onEnable() {
        saveResource("config.yml");
        saveResource("ranks.yml");
        saveResource("cosmetics.yml");
        saveResource("shop.yml");
        saveResource("kits.yml");
        saveResource("cases.yml");
        reload();
        getServer().getPluginManager().registerEvents(cases, this);
        forms = new Forms();
        cmds = new Cmds(this);
        extra = new Extra(this, config);
        tele = new Tele(this);
        combat = new Combat(this, config);
        clans = new Clans(this, config);
        board = new Board(this, config);
        regions = new Regions(this);
        pshop = new PShop(this);
        overrideNative("ban", "banlist", "kick");
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(cmds, this);
        getServer().getPluginManager().registerEvents(extra, this);
        getServer().getPluginManager().registerEvents(regions, this);
        getServer().getPluginManager().registerEvents(combat, this);
        getServer().getPluginManager().registerEvents(clans, this);
        getServer().getPluginManager().registerEvents(forms, this);
        getServer().getPluginManager().registerEvents(shop, this);
        getLogger().info("DonateCore включён: привилегий " + ranks.donate.size()
                + ", косметик " + cosmetics.all.size());
    }

    @Override
    public void onDisable() {
        if (store != null) store.save();
        if (cmds != null) cmds.punish.save();
    }

    private void reload() {
        File d = getDataFolder();
        Config c = new Config(new File(d, "config.yml"), Config.YAML);
        config = c;
        owners = new HashSet<>();
        ownerOrder = new ArrayList<>();
        ownerDisplay = new HashMap<>();
        for (Map.Entry<String, Object> e : U.m(c.get("owner_display")).entrySet())
            ownerDisplay.put(e.getKey().toLowerCase(Locale.ROOT), String.valueOf(e.getValue()));
        for (Object o : U.l(c.get("owners"))) {
            String n = String.valueOf(o).toLowerCase(Locale.ROOT);
            if (owners.add(n)) ownerOrder.add(n);
        }
        ownersNeedXbox = U.b(c.get("owners_require_xbox"), true);
        this.cfgAuthMin = U.i(U.m(c.get("auth")).get("min_password_length"), 6);
        this.cfgAuthMax = U.i(U.m(c.get("auth")).get("max_attempts"), 5);
        this.cfgAuthTimeout = U.i(U.m(c.get("auth")).get("login_timeout_seconds"), 60);
        this.nativePerms = U.m(c.get("native_permissions"));
        ranks = new Ranks(new Config(new File(d, "ranks.yml"), Config.YAML));
        cosmetics = new Cosmetics(new Config(new File(d, "cosmetics.yml"), Config.YAML));
        store = new Store(new File(d, "players.yml"));
        shop = new Shop(this, new Config(new File(d, "shop.yml"), Config.YAML));
        cases = new Cases(this, new Config(new File(d, "cases.yml"), Config.YAML));
    }

    /** Встроенные /ban, /banlist, /kick заменяем нашими (с лимитами по привилегиям). */
    private void overrideNative(String... names) {
        for (String n : names) {
            try {
                cn.nukkit.command.Command ours = (cn.nukkit.command.Command) getCommand(n);
                if (ours == null) continue;
                getServer().getCommandMap().getCommands().remove(n);
                getServer().getCommandMap().getCommands().put(n, ours);
            } catch (Throwable t) {
                getLogger().warning("Не удалось заменить команду /" + n + ": " + t.getMessage());
            }
        }
    }

    private int cfgAuthMin, cfgAuthMax, cfgAuthTimeout;
    private Map<String, Object> nativePerms = new HashMap<>();

    // ======================================================== вспомогательное

    public boolean isAuthed(Player p) {
        return authed.contains(p.getUniqueId());
    }

    public boolean isOwner(Player p) {
        if (!owners.contains(p.getName().toLowerCase(Locale.ROOT))) return false;
        if (!ownersNeedXbox) return true;
        try {
            return p.getLoginChainData().isXboxAuthed();
        } catch (Throwable t) {
            return false;
        }
    }

    /** Приоритет владельца: чем выше число, тем главнее. 0 - не владелец. Первый ник в config.yml -> owners главнее всех. */
    public int ownerLevel(String name) {
        int i = ownerOrder.indexOf(name.toLowerCase(Locale.ROOT));
        return i < 0 ? 0 : ownerOrder.size() - i;
    }

    /** Ранг для ОТОБРАЖЕНИЯ (чат, табло, /whois). У владельцев может отличаться от реального (config.yml -> owner_display). */
    public Ranks.Rank displayRank(Player p) {
        if (isOwner(p)) {
            String id = ownerDisplay.get(p.getName().toLowerCase(Locale.ROOT));
            Ranks.Rank r = id == null ? null : ranks.staff.get(id);
            if (r != null) return r;
        }
        return rankOf(p);
    }

    public Ranks.Rank rankOf(Player p) {
        if (isOwner(p)) {
            // главный владелец (первый в списке) = Владелец, остальные = Создатель
            boolean top = !ownerOrder.isEmpty() && ownerLevel(p.getName()) == ownerOrder.size();
            Ranks.Rank r = ranks.staff.get(top ? "owner" : "creator");
            return r != null ? r : ranks.staff.get("creator");
        }
        return ranks.byId(store.get(p.getName()).rank);
    }

    /** Для других плагинов (дома, регионы, варпы): лимит по привилегии игрока. */
    public int getLimit(Player p, String key, int def) {
        Ranks.Rank r = rankOf(p);
        return r == null ? def : ranks.limits(r).getOrDefault(key, def);
    }

    /** Лимит по привилегии (дома, регионы, магазины...). Без привилегии - значения из config.yml -> defaults. */
    public int lim(Player p, String key) {
        if (isOwner(p)) return Integer.MAX_VALUE;
        Ranks.Rank r = rankOf(p);
        Integer v = r == null ? null : ranks.limits(r).get(key);
        return v != null ? v : U.i(U.m(config.get("defaults")).get(key), 0);
    }

    public boolean hasImmunity(Player p) {
        Ranks.Rank r = rankOf(p);
        return r != null && ranks.immunity(r);
    }

    private boolean hasCosmetic(Player p, String id) {
        return isOwner(p) || store.get(p.getName()).cosmetics.contains(id);
    }

    public void applyPerms(Player p) {
        PermissionAttachment old = attachments.remove(p.getUniqueId());
        if (old != null) p.removeAttachment(old);
        PermissionAttachment a = p.addAttachment(this);
        attachments.put(p.getUniqueId(), a);
        Ranks.Rank r = rankOf(p);
        if (r == null) return;
        for (String cmd : ranks.commands(r)) {
            a.setPermission(cmd.startsWith("kit:") ? "donate.kit." + cmd.substring(4) : "donate.cmd." + cmd, true);
            for (Object np : U.l(nativePerms.get(cmd))) a.setPermission(String.valueOf(np), true);
        }
        if (r.op || isOwner(p)) {
            a.setPermission("donate.admin", true);
            p.setOp(true);
        }
    }

    private String prefixes(Player p) {
        Store.PD d = store.get(p.getName());
        StringBuilder sb = new StringBuilder(clans.tag(p));
        Cosmetics.Cos c = cosmetics.get(d.activeCosmetic);
        if (c != null && hasCosmetic(p, c.id)) sb.append(c.prefix).append(' ');
        Ranks.Rank own = displayRank(p);
        if (!"none".equals(d.activePref)) {
            Ranks.Rank pick = own;
            if (!d.activePref.isEmpty()) {
                Ranks.Rank chosen = ranks.byId(d.activePref);
                if (chosen != null && ranks.selectablePrefixes(own, isOwner(p)).contains(chosen)) pick = chosen;
            }
            if (pick != null) sb.append(pick.prefix).append(' ');
        }
        return sb.toString();
    }

    // ======================================================== авторизация

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        authed.remove(p.getUniqueId());
        attempts.remove(p.getUniqueId());
        Punish.Rec ban = cmds.punish.active("ban", p.getName());
        if (ban != null) {
            p.kick(PlayerKickEvent.Reason.UNKNOWN, "§cВы забанены до "
                    + (ban.until == 0 ? "навсегда" : new java.text.SimpleDateFormat("dd.MM HH:mm").format(new Date(ban.until)))
                    + "\n§7Причина: " + ban.reason, false);
            return;
        }
        if (store.get(p.getName()).pass.isEmpty()) {
            p.sendMessage("§eДобро пожаловать! Зарегистрируйтесь: §f/register <пароль> <пароль>");
        } else {
            p.sendMessage("§eВойдите в аккаунт: §f/login <пароль>");
        }
        if (cfgAuthTimeout > 0) {
            getServer().getScheduler().scheduleDelayedTask(this, () -> {
                if (p.isOnline() && !isAuthed(p)) p.kick("Время на вход истекло");
            }, cfgAuthTimeout * 20);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        authed.remove(id);
        attempts.remove(id);
        board.forget(e.getPlayer());
        clans.forget(e.getPlayer());
        PermissionAttachment a = attachments.remove(id);
        if (a != null) e.getPlayer().removeAttachment(a);
        store.save();
    }

    private void finishAuth(Player p) {
        authed.add(p.getUniqueId());
        attempts.remove(p.getUniqueId());
        applyPerms(p);
        if (!p.isOp() && owners.contains(p.getName().toLowerCase(Locale.ROOT)) && !isOwner(p)) {
            getLogger().warning("Ник владельца " + p.getName() + " зашёл без Xbox-авторизации: права не выданы.");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onMove(PlayerMoveEvent e) {
        if (!isAuthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBreak(BlockBreakEvent e) {
        if (!isAuthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlace(BlockPlaceEvent e) {
        if (!isAuthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrop(PlayerDropItemEvent e) {
        if (!isAuthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInteractAuth(PlayerInteractEvent e) {
        if (!isAuthed(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player && !isAuthed((Player) e.getEntity())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCmdPre(PlayerCommandPreprocessEvent e) {
        if (isAuthed(e.getPlayer())) return;
        String m = e.getMessage().toLowerCase(Locale.ROOT);
        if (m.startsWith("/login") || m.startsWith("/register")) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage("§cСначала войдите: /login или /register");
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(PlayerChatEvent e) {
        Player p = e.getPlayer();
        e.setCancelled(true);
        if (!isAuthed(p)) {
            p.sendMessage("§cСначала войдите: /login или /register");
            return;
        }
        Punish.Rec mute = cmds.punish.active("mute", p.getName());
        if (mute != null) {
            p.sendMessage("§cВы замучены" + (mute.until == 0 ? "" : " до " + new java.text.SimpleDateFormat("dd.MM HH:mm").format(new Date(mute.until)))
                    + ". Причина: " + mute.reason);
            return;
        }
        String msg = e.getMessage().replace("§", "");
        if (clans.chatHook(p, msg)) return;
        String line = prefixes(p) + "§f" + p.getName() + "§7: §f" + msg;
        for (CommandSender r : e.getRecipients()) r.sendMessage(line);
        getLogger().info(TextFormat.clean(line));
    }

    // ======================================================== команды

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String c = cmd.getName().toLowerCase(Locale.ROOT);
        switch (c) {
            case "register": return cmdRegister(sender, args);
            case "login": return cmdLogin(sender, args);
            case "coins": return cmdBalance(sender, args, false);
            case "money": return cmdBalance(sender, args, true);
            case "case": return cmdCase(sender, args);
            case "sethome": case "home": case "delhome": case "homes":
            case "tpa": case "tpaccept": case "tpdeny": case "setspawn":
                return tele.handle(sender, c, args);
            case "rg": return regions.handle(sender, args);
            case "arena": return combat.arenaCommand(sender, args);
            case "sb": return board.command(sender);
            case "clan": case "cc": return clans.handle(sender, c, args);
            case "shop": return pshop.handle(sender, args);
            case "setrank": return cmdSetRank(sender, args);
            case "pref": return cmdPref(sender);
            case "cosmetic": return cmdCosmetic(sender);
            case "donshop":
                if (!(sender instanceof Player)) return noConsole(sender);
                shop.open((Player) sender);
                return true;
            case "limits": return cmdLimits(sender);
            case "fly": case "heal": case "feed": case "ext": case "getpos":
                return basic(sender, c, args);
            default: return cmds.handle(sender, c, args);
        }
    }

    private boolean noConsole(CommandSender s) {
        s.sendMessage("Эту команду можно выполнить только в игре.");
        return true;
    }

    private boolean cmdRegister(CommandSender s, String[] a) {
        if (!(s instanceof Player)) return noConsole(s);
        Player p = (Player) s;
        Store.PD d = store.get(p.getName());
        if (!d.pass.isEmpty()) { p.sendMessage("§cВы уже зарегистрированы. Используйте /login"); return true; }
        if (a.length != 2 || !a[0].equals(a[1])) { p.sendMessage("§cИспользование: /register <пароль> <пароль> (пароли должны совпадать)"); return true; }
        if (a[0].length() < cfgAuthMin) { p.sendMessage("§cПароль слишком короткий (минимум " + cfgAuthMin + ")."); return true; }
        d.pass = Store.hash(a[0]);
        store.save();
        finishAuth(p);
        p.sendMessage("§aРегистрация успешна!");
        return true;
    }

    private boolean cmdLogin(CommandSender s, String[] a) {
        if (!(s instanceof Player)) return noConsole(s);
        Player p = (Player) s;
        if (isAuthed(p)) { p.sendMessage("§eВы уже вошли."); return true; }
        Store.PD d = store.get(p.getName());
        if (d.pass.isEmpty()) { p.sendMessage("§cСначала /register <пароль> <пароль>"); return true; }
        if (a.length != 1) { p.sendMessage("§cИспользование: /login <пароль>"); return true; }
        if (Store.check(a[0], d.pass)) {
            finishAuth(p);
            p.sendMessage("§aВы вошли.");
        } else {
            int n = attempts.merge(p.getUniqueId(), 1, Integer::sum);
            if (n >= cfgAuthMax) p.kick("Слишком много неверных паролей");
            else p.sendMessage("§cНеверный пароль. Осталось попыток: " + (cfgAuthMax - n));
        }
        return true;
    }

    /** /coins (койны, донат-валюта) и /money (игровые монеты): баланс и управление для админов. */
    private boolean cmdBalance(CommandSender s, String[] a, boolean money) {
        String cmdName = money ? "money" : "coins";
        String unit = money ? "монет" : "койнов";
        if (a.length == 0) {
            if (!(s instanceof Player)) return noConsole(s);
            Store.PD me = store.get(((Player) s).getName());
            s.sendMessage("§eВаш баланс: §f" + (money ? me.money : me.coins) + " " + unit);
            return true;
        }
        if (!s.hasPermission("donate.admin")) { s.sendMessage("§cНет прав."); return true; }
        if (a.length == 1) {
            Store.PD x = store.get(a[0]);
            s.sendMessage("§e" + a[0] + ": §f" + (money ? x.money : x.coins) + " " + unit);
            return true;
        }
        if (a.length != 3) { s.sendMessage("§c/" + cmdName + " give|take|set <ник> <число>"); return true; }
        long n;
        try { n = Long.parseLong(a[2]); } catch (NumberFormatException e) { s.sendMessage("§cЧисло неверное."); return true; }
        if (n < 0 || n > 1_000_000_000L) { s.sendMessage("§cДопустимо от 0 до 1 000 000 000."); return true; }
        Player online = getServer().getPlayerExact(a[1]);
        if (online == null && !store.exists(a[1])) { s.sendMessage("§cИгрок не найден."); return true; }
        Store.PD d = store.get(a[1]);
        long cur = money ? d.money : d.coins;
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "give": cur += n; break;
            case "take": cur = Math.max(0, cur - n); break;
            case "set": cur = n; break;
            default: s.sendMessage("§c/" + cmdName + " give|take|set <ник> <число>"); return true;
        }
        if (money) d.money = cur; else d.coins = cur;
        store.save();
        s.sendMessage("§aБаланс " + a[1] + ": " + cur + " " + unit);
        if (online != null) online.sendMessage("§eВаш баланс изменён: §f" + cur + " " + unit);
        getLogger().info(s.getName() + " /" + cmdName + " " + String.join(" ", a));
        return true;
    }

    private boolean cmdCase(CommandSender s, String[] a) {
        if (a.length >= 1 && (a[0].equalsIgnoreCase("setblock") || a[0].equalsIgnoreCase("delblock") || a[0].equalsIgnoreCase("blocks"))) {
            if (!(s instanceof Player)) return noConsole(s);
            return cases.blockCommand((Player) s, a[0].toLowerCase(Locale.ROOT), a);
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("give")) {
            if (!s.hasPermission("donate.admin")) { s.sendMessage("§cНет прав."); return true; }
            if (a.length < 3) { s.sendMessage("§c/case give <ник> <" + String.join("|", cases.ids()) + "> [число]"); return true; }
            if (getServer().getPlayerExact(a[1]) == null && !store.exists(a[1])) { s.sendMessage("§cИгрок не найден."); return true; }
            int n = 1;
            try { if (a.length > 3) n = Integer.parseInt(a[3]); } catch (NumberFormatException e) { s.sendMessage("§cЧисло неверное."); return true; }
            s.sendMessage(cases.giveKeys(a[1], a[2].toLowerCase(Locale.ROOT), n));
            getLogger().info(s.getName() + " /case " + String.join(" ", a));
            return true;
        }
        if (!(s instanceof Player)) return noConsole(s);
        Player p = (Player) s;
        if (!isAuthed(p)) return true;
        cases.menu(p);
        return true;
    }

    private boolean cmdSetRank(CommandSender s, String[] a) {
        if (a.length != 2) {
            s.sendMessage("§c/setrank <ник> <id|none>. Доступно: " + String.join(", ", ranks.donate.keySet())
                    + ", " + String.join(", ", ranks.staff.keySet()));
            return true;
        }
        String id = a[1].equalsIgnoreCase("none") ? "" : a[1].toLowerCase(Locale.ROOT);
        if (!id.isEmpty() && ranks.byId(id) == null) { s.sendMessage("§cТакой привилегии нет."); return true; }
        // выдавать staff-ранги могут только консоль и владельцы
        Ranks.Rank target = ranks.byId(id);
        Ranks.Rank myRank = s instanceof Player ? rankOf((Player) s) : null;
        if (target != null && target.staff && s instanceof Player && !isOwner((Player) s)
                && !(myRank != null && "creator".equals(myRank.id))) {
            s.sendMessage("§cРанги администрации выдаёт только владелец, Создатель или консоль.");
            return true;
        }
        // ранг "Владелец" выдаёт только консоль или главный владелец; ранги владельцев из config.yml менять нельзя
        if (target != null && "owner".equals(target.id) && s instanceof Player
                && !(isOwner((Player) s) && ownerLevel(s.getName()) == ownerOrder.size())) {
            s.sendMessage("§cНе удалось выполнить команду.");
            return true;
        }
        if (ownerLevel(a[0]) > 0 && s instanceof Player && ownerLevel(a[0]) >= ownerLevel(s.getName())) {
            s.sendMessage("§cНе удалось выполнить команду.");
            return true;
        }
        Player online = getServer().getPlayerExact(a[0]);
        if (online == null && !store.exists(a[0])) { s.sendMessage("§cИгрок не найден."); return true; }
        Store.PD d = store.get(a[0]);
        Ranks.Rank old = ranks.byId(d.rank);
        d.rank = id;
        store.save();
        if (online != null) {
            if (old != null && old.op && (target == null || !target.op) && !isOwner(online)) online.setOp(false);
            if (isAuthed(online)) applyPerms(online);
            online.sendMessage("§aВаша привилегия: " + (target == null ? "нет" : target.name));
        }
        s.sendMessage("§aПривилегия " + a[0] + ": " + (target == null ? "нет" : target.name));
        getLogger().info(s.getName() + " /setrank " + a[0] + " " + id);
        return true;
    }

    private boolean cmdLimits(CommandSender s) {
        if (!(s instanceof Player)) return noConsole(s);
        Player p = (Player) s;
        Ranks.Rank r = rankOf(p);
        if (r == null) { p.sendMessage("§7У вас нет привилегии."); return true; }
        StringBuilder sb = new StringBuilder("§eЛимиты (" + r.name + "):");
        for (Map.Entry<String, Integer> e : ranks.limits(r).entrySet())
            sb.append("\n§7").append(e.getKey()).append(": §f").append(e.getValue());
        p.sendMessage(sb.toString());
        return true;
    }

    // ---------- /pref : префиксы привилегий (своя и ниже) ----------
    private boolean cmdPref(CommandSender s) {
        if (!(s instanceof Player)) return noConsole(s);
        Player p = (Player) s;
        if (!isAuthed(p)) return true;
        List<Ranks.Rank> list = ranks.selectablePrefixes(rankOf(p), isOwner(p));
        if (list.isEmpty()) { p.sendMessage("§cУ вас нет привилегии, префиксов нет."); return true; }
        List<String> b = new ArrayList<>();
        for (Ranks.Rank r : list) b.add(r.prefix);
        b.add("§7Убрать префикс");
        b.add("§7По умолчанию");
        forms.simple(p, "§lПрефиксы привилегий", "Выберите префикс:", b, idx -> {
            Store.PD d = store.get(p.getName());
            if (idx < list.size()) d.activePref = list.get(idx).id;
            else if (idx == list.size()) d.activePref = "none";
            else d.activePref = "";
            store.save();
            p.sendMessage("§aПрефикс обновлён.");
        });
        return true;
    }

    // ---------- /cosmetic : свои косметические префиксы и покупка ----------
    private boolean cmdCosmetic(CommandSender s) {
        if (!(s instanceof Player)) return noConsole(s);
        Player p = (Player) s;
        if (!isAuthed(p)) return true;
        forms.simple(p, "§lКосметика", "Баланс: §e" + store.get(p.getName()).coins + " койнов",
                Arrays.asList("Мои префиксы", "Купить за койны", "Убрать префикс"), idx -> {
                    if (idx == 0) cosMine(p);
                    else if (idx == 1) cosBuy(p);
                    else if (idx == 2) { store.get(p.getName()).activeCosmetic = ""; store.save(); p.sendMessage("§aПрефикс убран."); }
                });
        return true;
    }

    private void cosMine(Player p) {
        List<Cosmetics.Cos> mine = new ArrayList<>();
        for (Cosmetics.Cos c : cosmetics.all.values()) if (hasCosmetic(p, c.id)) mine.add(c);
        if (mine.isEmpty()) { p.sendMessage("§7У вас пока нет косметических префиксов. Купите их в /cosmetic или выбейте в кейсе."); return; }
        List<String> b = new ArrayList<>();
        for (Cosmetics.Cos c : mine) b.add(c.prefix);
        forms.simple(p, "Мои префиксы", "Нажмите, чтобы надеть:", b, idx -> {
            if (idx < 0 || idx >= mine.size()) return;
            store.get(p.getName()).activeCosmetic = mine.get(idx).id;
            store.save();
            p.sendMessage("§aПрефикс надет: " + mine.get(idx).prefix);
        });
    }

    private void cosBuy(Player p) {
        List<Cosmetics.Cos> list = new ArrayList<>(cosmetics.all.values());
        List<String> b = new ArrayList<>();
        for (Cosmetics.Cos c : list)
            b.add(c.prefix + "\n§8" + (hasCosmetic(p, c.id) ? "куплен" : c.price + " койнов"));
        forms.simple(p, "Магазин префиксов", "Баланс: §e" + store.get(p.getName()).coins, b, idx -> {
            if (idx < 0 || idx >= list.size()) return;
            Cosmetics.Cos c = list.get(idx);
            if (hasCosmetic(p, c.id)) { p.sendMessage("§7У вас уже есть этот префикс."); return; }
            forms.confirm(p, "Покупка", c.prefix + "\n\nЦена: §e" + c.price + " койнов", () -> {
                Store.PD d = store.get(p.getName());
                if (d.cosmetics.contains(c.id)) return;
                if (d.coins < c.price) { p.sendMessage("§cНедостаточно койнов."); return; }
                d.coins -= c.price;
                d.cosmetics.add(c.id);
                store.save();
                p.sendMessage("§aКуплено: " + c.prefix + "§a. Наденьте в /cosmetic → Мои префиксы.");
            });
        });
    }

    // ---------- первые простые команды из списка привилегий ----------
    private boolean basic(CommandSender s, String c, String[] a) {
        Player target;
        if (a.length >= 1 && !c.equals("getpos")) {
            if (!s.hasPermission("donate.cmd." + c + ".other") && !s.isOp()) { s.sendMessage("§cНет прав на команду для другого игрока."); return true; }
            target = getServer().getPlayer(a[0]);
            if (target == null) { s.sendMessage("§cИгрок не найден."); return true; }
        } else if (s instanceof Player) {
            target = (Player) s;
        } else {
            return noConsole(s);
        }
        switch (c) {
            case "fly":
                target.setAllowFlight(!target.getAllowFlight());
                target.sendMessage(target.getAllowFlight() ? "§aПолёт включён." : "§cПолёт выключен.");
                break;
            case "heal":
                target.setHealth(target.getMaxHealth());
                target.sendMessage("§aВы исцелены.");
                break;
            case "feed":
                target.getFoodData().setLevel(20, 20f);
                target.sendMessage("§aГолод восстановлен.");
                break;
            case "ext":
                target.extinguish();
                target.sendMessage("§aВы потушены.");
                break;
            case "getpos":
                s.sendMessage("§eПозиция: §f" + target.getFloorX() + ", " + target.getFloorY() + ", " + target.getFloorZ()
                        + " §7(" + target.getLevel().getName() + ")");
                break;
            default:
                return false;
        }
        return true;
    }
}
